from provincia import Provincia
from geografia import Pais, Continente


class Seeder:
    """Inicializa todos los datos del mundo (América + Europa)."""

    @staticmethod
    def inicializar_datos() -> dict[str, Continente]:
        """
        Crea y retorna un dict {nombre_continente: Continente}
        con todos los países, provincias y límites cargados.
        """
        america = Continente("América")
        europa  = Continente("Europa")

        Seeder._cargar_america(america)
        Seeder._cargar_europa(europa)
        Seeder._cargar_limitrofes_america(america)
        Seeder._cargar_limitrofes_europa(europa)

        return {"América": america, "Europa": europa}

    # ══════════════════════════════════════
    #  CARGA DE PAÍSES — AMÉRICA
    # ══════════════════════════════════════

    @staticmethod
    def _cargar_america(america: Continente) -> None:
        paises = [
            Seeder._crear_argentina(),
            Seeder._crear_brasil(),
            Seeder._crear_chile(),
            Seeder._crear_uruguay(),
            Seeder._crear_paraguay(),
            Seeder._crear_bolivia(),
            Seeder._crear_peru(),
            Seeder._crear_colombia(),
            Seeder._crear_venezuela(),
            Seeder._crear_ecuador(),
            Seeder._crear_mexico(),
            Seeder._crear_eeuu(),
            Seeder._crear_canada(),
            Seeder._crear_cuba(),
            Seeder._crear_guatemala(),
            Seeder._crear_honduras(),
            Seeder._crear_costa_rica(),
            Seeder._crear_panama(),
        ]
        for p in paises:
            america.agregar_pais(p)

    @staticmethod
    def _crear_argentina() -> Pais:
        p = Pais("Argentina", "Buenos Aires", 2_780_400)
        for prov in ["Buenos Aires", "Córdoba", "Santa Fe", "Mendoza",
                     "Tucumán", "Salta", "Entre Ríos", "Misiones",
                     "Chaco", "Corrientes", "Santiago del Estero",
                     "San Juan", "Jujuy", "Río Negro", "Neuquén",
                     "Formosa", "La Pampa", "Chubut", "San Luis",
                     "Catamarca", "La Rioja", "Santa Cruz",
                     "Tierra del Fuego", "Ciudad Autónoma de Buenos Aires"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_brasil() -> Pais:
        p = Pais("Brasil", "Brasilia", 8_515_767)
        for estado in ["São Paulo", "Minas Gerais", "Rio de Janeiro",
                       "Bahia", "Paraná", "Rio Grande do Sul",
                       "Pernambuco", "Ceará", "Pará", "Maranhão",
                       "Santa Catarina", "Goiás", "Amazonas",
                       "Espírito Santo", "Mato Grosso", "Mato Grosso do Sul",
                       "Paraíba", "Rio Grande do Norte", "Alagoas",
                       "Piauí", "Rondônia", "Sergipe", "Tocantins",
                       "Acre", "Amapá", "Roraima", "Distrito Federal"]:
            p.agregar_provincia(Provincia(estado))
        return p

    @staticmethod
    def _crear_chile() -> Pais:
        p = Pais("Chile", "Santiago", 756_102)
        for region in ["Tarapacá", "Antofagasta", "Atacama", "Coquimbo",
                       "Valparaíso", "O'Higgins", "Maule", "Biobío",
                       "La Araucanía", "Los Lagos", "Aysén",
                       "Magallanes", "Metropolitana de Santiago",
                       "Los Ríos", "Arica y Parinacota", "Ñuble"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_uruguay() -> Pais:
        p = Pais("Uruguay", "Montevideo", 176_215)
        for dept in ["Montevideo", "Canelones", "Maldonado", "Rocha",
                     "Treinta y Tres", "Cerro Largo", "Rivera",
                     "Artigas", "Salto", "Paysandú", "Río Negro",
                     "Soriano", "Colonia", "San José", "Flores",
                     "Florida", "Lavalleja", "Durazno", "Tacuarembó"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_paraguay() -> Pais:
        p = Pais("Paraguay", "Asunción", 406_752)
        for dept in ["Asunción", "Concepción", "San Pedro", "Cordillera",
                     "Guairá", "Caaguazú", "Caazapá", "Itapúa",
                     "Misiones", "Paraguarí", "Alto Paraná", "Central",
                     "Ñeembucú", "Amambay", "Canindeyú", "Presidente Hayes",
                     "Boquerón", "Alto Paraguay"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_bolivia() -> Pais:
        p = Pais("Bolivia", "Sucre", 1_098_581)
        for dept in ["La Paz", "Cochabamba", "Santa Cruz", "Potosí",
                     "Oruro", "Beni", "Chuquisaca", "Tarija", "Pando"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_peru() -> Pais:
        p = Pais("Perú", "Lima", 1_285_216)
        for dept in ["Amazonas", "Áncash", "Apurímac", "Arequipa",
                     "Ayacucho", "Cajamarca", "Callao", "Cusco",
                     "Huancavelica", "Huánuco", "Ica", "Junín",
                     "La Libertad", "Lambayeque", "Lima", "Loreto",
                     "Madre de Dios", "Moquegua", "Pasco", "Piura",
                     "Puno", "San Martín", "Tacna", "Tumbes", "Ucayali"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_colombia() -> Pais:
        p = Pais("Colombia", "Bogotá", 1_141_748)
        for dept in ["Amazonas", "Antioquia", "Arauca", "Atlántico",
                     "Bolívar", "Boyacá", "Caldas", "Caquetá",
                     "Casanare", "Cauca", "Cesar", "Chocó",
                     "Córdoba", "Cundinamarca", "Guainía", "Guaviare",
                     "Huila", "La Guajira", "Magdalena", "Meta",
                     "Nariño", "Norte de Santander", "Putumayo",
                     "Quindío", "Risaralda", "San Andrés", "Santander",
                     "Sucre", "Tolima", "Valle del Cauca", "Vaupés", "Vichada"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_venezuela() -> Pais:
        p = Pais("Venezuela", "Caracas", 916_445)
        for estado in ["Amazonas", "Anzoátegui", "Apure", "Aragua",
                       "Barinas", "Bolívar", "Carabobo", "Cojedes",
                       "Delta Amacuro", "Falcón", "Guárico", "Lara",
                       "Mérida", "Miranda", "Monagas", "Nueva Esparta",
                       "Portuguesa", "Sucre", "Táchira", "Trujillo",
                       "La Guaira", "Yaracuy", "Zulia", "Distrito Capital"]:
            p.agregar_provincia(Provincia(estado))
        return p

    @staticmethod
    def _crear_ecuador() -> Pais:
        p = Pais("Ecuador", "Quito", 283_561)
        for prov in ["Azuay", "Bolívar", "Cañar", "Carchi", "Chimborazo",
                     "Cotopaxi", "El Oro", "Esmeraldas", "Galápagos",
                     "Guayas", "Imbabura", "Loja", "Los Ríos",
                     "Manabí", "Morona Santiago", "Napo", "Orellana",
                     "Pastaza", "Pichincha", "Santa Elena",
                     "Santo Domingo", "Sucumbíos", "Tungurahua", "Zamora Chinchipe"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_mexico() -> Pais:
        p = Pais("México", "Ciudad de México", 1_964_375)
        for estado in ["Aguascalientes", "Baja California", "Baja California Sur",
                       "Campeche", "Chiapas", "Chihuahua", "Ciudad de México",
                       "Coahuila", "Colima", "Durango", "Estado de México",
                       "Guanajuato", "Guerrero", "Hidalgo", "Jalisco",
                       "Michoacán", "Morelos", "Nayarit", "Nuevo León",
                       "Oaxaca", "Puebla", "Querétaro", "Quintana Roo",
                       "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco",
                       "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas"]:
            p.agregar_provincia(Provincia(estado))
        return p

    @staticmethod
    def _crear_eeuu() -> Pais:
        p = Pais("Estados Unidos", "Washington D.C.", 9_833_517)
        for estado in ["Alabama", "Alaska", "Arizona", "Arkansas",
                       "California", "Colorado", "Connecticut", "Delaware",
                       "Florida", "Georgia", "Hawái", "Idaho", "Illinois",
                       "Indiana", "Iowa", "Kansas", "Kentucky", "Luisiana",
                       "Maine", "Maryland", "Massachusetts", "Míchigan",
                       "Minnesota", "Misisipi", "Misuri", "Montana",
                       "Nebraska", "Nevada", "Nuevo Hampshire", "Nueva Jersey",
                       "Nuevo México", "Nueva York", "Carolina del Norte",
                       "Dakota del Norte", "Ohio", "Oklahoma", "Oregón",
                       "Pensilvania", "Rhode Island", "Carolina del Sur",
                       "Dakota del Sur", "Tennessee", "Texas", "Utah",
                       "Vermont", "Virginia", "Washington", "Virginia Occidental",
                       "Wisconsin", "Wyoming", "Distrito de Columbia"]:
            p.agregar_provincia(Provincia(estado))
        return p

    @staticmethod
    def _crear_canada() -> Pais:
        p = Pais("Canadá", "Ottawa", 9_984_670)
        for prov in ["Alberta", "Columbia Británica", "Manitoba",
                     "Nueva Brunswick", "Terranova y Labrador",
                     "Nueva Escocia", "Ontario", "Isla del Príncipe Eduardo",
                     "Quebec", "Saskatchewan", "Territorios del Noroeste",
                     "Nunavut", "Yukón"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_cuba() -> Pais:
        p = Pais("Cuba", "La Habana", 109_884)
        for prov in ["Pinar del Río", "Artemisa", "La Habana", "Mayabeque",
                     "Matanzas", "Cienfuegos", "Villa Clara", "Sancti Spíritus",
                     "Ciego de Ávila", "Camagüey", "Las Tunas", "Holguín",
                     "Granma", "Santiago de Cuba", "Guantánamo",
                     "Isla de la Juventud"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_guatemala() -> Pais:
        p = Pais("Guatemala", "Ciudad de Guatemala", 108_889)
        for dept in ["Alta Verapaz", "Baja Verapaz", "Chimaltenango",
                     "Chiquimula", "El Progreso", "Escuintla", "Guatemala",
                     "Huehuetenango", "Izabal", "Jalapa", "Jutiapa",
                     "Petén", "Quetzaltenango", "Quiché", "Retalhuleu",
                     "Sacatepéquez", "San Marcos", "Santa Rosa",
                     "Sololá", "Suchitepéquez", "Totonicapán", "Zacapa"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_honduras() -> Pais:
        p = Pais("Honduras", "Tegucigalpa", 112_492)
        for dept in ["Atlántida", "Choluteca", "Colón", "Comayagua",
                     "Copán", "Cortés", "El Paraíso", "Francisco Morazán",
                     "Gracias a Dios", "Intibucá", "Islas de la Bahía",
                     "La Paz", "Lempira", "Ocotepeque", "Olancho",
                     "Santa Bárbara", "Valle", "Yoro"]:
            p.agregar_provincia(Provincia(dept))
        return p

    @staticmethod
    def _crear_costa_rica() -> Pais:
        p = Pais("Costa Rica", "San José", 51_100)
        for prov in ["San José", "Alajuela", "Cartago", "Heredia",
                     "Guanacaste", "Puntarenas", "Limón"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_panama() -> Pais:
        p = Pais("Panamá", "Ciudad de Panamá", 75_417)
        for prov in ["Bocas del Toro", "Coclé", "Colón", "Chiriquí",
                     "Darién", "Herrera", "Los Santos", "Panamá",
                     "Veraguas", "Panamá Oeste", "Guna Yala",
                     "Emberá", "Ngäbe-Buglé"]:
            p.agregar_provincia(Provincia(prov))
        return p

    # ══════════════════════════════════════
    #  CARGA DE PAÍSES — EUROPA
    # ══════════════════════════════════════

    @staticmethod
    def _cargar_europa(europa: Continente) -> None:
        paises = [
            Seeder._crear_espana(),
            Seeder._crear_francia(),
            Seeder._crear_alemania(),
            Seeder._crear_italia(),
            Seeder._crear_portugal(),
            Seeder._crear_reino_unido(),
            Seeder._crear_polonia(),
            Seeder._crear_paises_bajos(),
            Seeder._crear_belgica(),
            Seeder._crear_suiza(),
            Seeder._crear_austria(),
            Seeder._crear_suecia(),
            Seeder._crear_noruega(),
            Seeder._crear_finlandia(),
            Seeder._crear_dinamarca(),
            Seeder._crear_grecia(),
            Seeder._crear_checia(),
            Seeder._crear_hungria(),
            Seeder._crear_rumania(),
        ]
        for p in paises:
            europa.agregar_pais(p)

    @staticmethod
    def _crear_espana() -> Pais:
        p = Pais("España", "Madrid", 505_990)
        for ccaa in ["Andalucía", "Aragón", "Asturias", "Baleares",
                     "Canarias", "Cantabria", "Castilla-La Mancha",
                     "Castilla y León", "Cataluña", "Extremadura",
                     "Galicia", "La Rioja", "Madrid", "Murcia",
                     "Navarra", "País Vasco", "Valencia",
                     "Ceuta", "Melilla"]:
            p.agregar_provincia(Provincia(ccaa))
        return p

    @staticmethod
    def _crear_francia() -> Pais:
        p = Pais("Francia", "París", 643_801)
        for region in ["Auvernia-Ródano-Alpes", "Borgoña-Franco Condado",
                       "Bretaña", "Centro-Valle del Loira",
                       "Córcega", "Gran Este", "Guadalupe", "Guayana Francesa",
                       "Hauts-de-France", "Isla de Francia",
                       "Martinica", "Mayotte", "Normandía",
                       "Nueva Aquitania", "Occitania",
                       "Países del Loira", "Provenza-Alpes-Costa Azul",
                       "Reunión"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_alemania() -> Pais:
        p = Pais("Alemania", "Berlín", 357_114)
        for land in ["Badén-Wurtemberg", "Baviera", "Berlín",
                     "Brandeburgo", "Bremen", "Hamburgo",
                     "Hesse", "Mecklemburgo-Pomerania Occidental",
                     "Baja Sajonia", "Renania del Norte-Westfalia",
                     "Renania-Palatinado", "Sarre",
                     "Sajonia", "Sajonia-Anhalt",
                     "Schleswig-Holstein", "Turingia"]:
            p.agregar_provincia(Provincia(land))
        return p

    @staticmethod
    def _crear_italia() -> Pais:
        p = Pais("Italia", "Roma", 301_340)
        for region in ["Abruzo", "Basilicata", "Calabria", "Campania",
                       "Emilia-Romaña", "Friul-Venecia Julia",
                       "Lacio", "Liguria", "Lombardía",
                       "Marcas", "Molise", "Piamonte",
                       "Apulia", "Cerdeña", "Sicilia",
                       "Toscana", "Trentino-Alto Adigio",
                       "Umbría", "Valle de Aosta", "Véneto"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_portugal() -> Pais:
        p = Pais("Portugal", "Lisboa", 92_212)
        for dist in ["Aveiro", "Beja", "Braga", "Braganza",
                     "Castelo Branco", "Coímbra", "Évora",
                     "Faro", "Guarda", "Leiría", "Lisboa",
                     "Portalegre", "Oporto", "Santarém",
                     "Setúbal", "Viana do Castelo",
                     "Vila Real", "Viseu",
                     "Azores", "Madeira"]:
            p.agregar_provincia(Provincia(dist))
        return p

    @staticmethod
    def _crear_reino_unido() -> Pais:
        p = Pais("Reino Unido", "Londres", 243_610)
        for nacion in ["Inglaterra", "Escocia", "Gales", "Irlanda del Norte"]:
            p.agregar_provincia(Provincia(nacion))
        return p

    @staticmethod
    def _crear_polonia() -> Pais:
        p = Pais("Polonia", "Varsovia", 312_679)
        for voiv in ["Baja Silesia", "Cuyavia-Pomerania", "Lodz",
                     "Lublin", "Lubusz", "Mazovia", "Małopolska",
                     "Opole", "Subcarpacia", "Podlaquia",
                     "Pomerania", "Silesia", "Santa Cruz",
                     "Varmia-Mazuria", "Gran Polonia",
                     "Pomerania Occidental"]:
            p.agregar_provincia(Provincia(voiv))
        return p

    @staticmethod
    def _crear_paises_bajos() -> Pais:
        p = Pais("Países Bajos", "Ámsterdam", 41_543)
        for prov in ["Groninga", "Frisia", "Drente", "Overijssel",
                     "Güeldres", "Utrecht", "Flevoland", "Holanda Septentrional",
                     "Holanda Meridional", "Zelanda",
                     "Brabante Septentrional", "Limburgo"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_belgica() -> Pais:
        p = Pais("Bélgica", "Bruselas", 30_528)
        for prov in ["Amberes", "Brabante Flamenco", "Brabante Valón",
                     "Brujas", "Gante", "Hainaut",
                     "Lieja", "Limburgo", "Luxemburgo",
                     "Namur"]:
            p.agregar_provincia(Provincia(prov))
        return p

    @staticmethod
    def _crear_suiza() -> Pais:
        p = Pais("Suiza", "Berna", 41_285)
        for canton in ["Zúrich", "Berna", "Lucerna", "Uri",
                       "Schwyz", "Obwalden", "Nidwalden",
                       "Glaris", "Zug", "Friburgo", "Soleura",
                       "Basilea Ciudad", "Basilea Campiña",
                       "Schaffhausen", "Appenzell Rodas Exteriores",
                       "Appenzell Rodas Interiores", "San Galo",
                       "Grisones", "Argovia", "Turgovia",
                       "Tesino", "Vaud", "Valais",
                       "Neuchâtel", "Ginebra", "Jura"]:
            p.agregar_provincia(Provincia(canton))
        return p

    @staticmethod
    def _crear_austria() -> Pais:
        p = Pais("Austria", "Viena", 83_871)
        for land in ["Burgenland", "Carintia", "Baja Austria",
                     "Alta Austria", "Salzburgo", "Estiria",
                     "Tirol", "Voralberg", "Viena"]:
            p.agregar_provincia(Provincia(land))
        return p

    @staticmethod
    def _crear_suecia() -> Pais:
        p = Pais("Suecia", "Estocolmo", 450_295)
        for lan in ["Blekinge", "Dalarna", "Gotland", "Gävleborg",
                    "Halland", "Jämtland", "Jönköping", "Kalmar",
                    "Kronoberg", "Norrbotten", "Örebro", "Östergötland",
                    "Skåne", "Södermanland", "Estocolmo", "Uppsala",
                    "Värmland", "Västerbotten", "Västernorrland",
                    "Västmanland", "Västra Götaland"]:
            p.agregar_provincia(Provincia(lan))
        return p

    @staticmethod
    def _crear_noruega() -> Pais:
        p = Pais("Noruega", "Oslo", 385_207)
        for condado in ["Viken", "Innlandet", "Vestfold og Telemark",
                        "Agder", "Rogaland", "Vestland",
                        "Møre og Romsdal", "Trøndelag",
                        "Nordland", "Troms og Finnmark",
                        "Oslo", "Svalbard"]:
            p.agregar_provincia(Provincia(condado))
        return p

    @staticmethod
    def _crear_finlandia() -> Pais:
        p = Pais("Finlandia", "Helsinki", 338_145)
        for region in ["Finlandia Meridional", "Finlandia Occidental",
                       "Finlandia Oriental", "Finlandia Central",
                       "Finlandia Septentrional", "Laponia",
                       "Ostrobotnia del Norte", "Ostrobotnia",
                       "Finlandia Meridional Propia",
                       "Ostrobotnia Meridional", "Carelía del Norte",
                       "Satakunta", "Tavastia Meridional",
                       "Tavastia Central", "Päijänne-Tavastia",
                       "Carelía del Sur", "Kymenlaakso",
                       "Uusimaa", "Åland"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_dinamarca() -> Pais:
        p = Pais("Dinamarca", "Copenhague", 42_924)
        for region in ["Capital", "Zelanda", "Syddanmark",
                       "Midtjylland", "Nordjylland"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_grecia() -> Pais:
        p = Pais("Grecia", "Atenas", 131_957)
        for region in ["Ática", "Macedonia Central", "Macedonia Occidental",
                       "Macedonia Oriental y Tracia", "Epiro", "Tesalia",
                       "Grecia Central", "Grecia Occidental",
                       "Peloponeso", "Islas Jónicas",
                       "Egeo Septentrional", "Egeo Meridional",
                       "Creta", "Monte Atos"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_checia() -> Pais:
        p = Pais("República Checa", "Praga", 78_867)
        for region in ["Bohemia Central", "Bohemia Meridional",
                       "Bohemia Occidental", "Bohemia Septentrional",
                       "Bohemia Oriental", "Moravia Meridional",
                       "Moravia-Silesia", "Moravia Oriental",
                       "Vysočina", "Hradec Králové",
                       "Liberec", "Olomouc",
                       "Pardubice", "Praga", "Ústí nad Labem"]:
            p.agregar_provincia(Provincia(region))
        return p

    @staticmethod
    def _crear_hungria() -> Pais:
        p = Pais("Hungría", "Budapest", 93_028)
        for condado in ["Bács-Kiskun", "Baranya", "Békés", "Borsod-Abaúj-Zemplén",
                        "Csongrád-Csanád", "Fejér", "Győr-Moson-Sopron",
                        "Hajdú-Bihar", "Heves", "Jász-Nagykun-Szolnok",
                        "Komárom-Esztergom", "Nógrád", "Pest",
                        "Somogy", "Szabolcs-Szatmár-Bereg",
                        "Tolna", "Vas", "Veszprém", "Zala",
                        "Budapest"]:
            p.agregar_provincia(Provincia(condado))
        return p

    @staticmethod
    def _crear_rumania() -> Pais:
        p = Pais("Rumanía", "Bucarest", 238_397)
        for region in ["Alba", "Arad", "Argeș", "Bacău", "Bihor",
                       "Bistrița-Năsăud", "Botoșani", "Brăila",
                       "Brașov", "Buzău", "Călărași", "Cluj",
                       "Constanța", "Covasna", "Dâmbovița",
                       "Dolj", "Galați", "Giurgiu", "Gorj",
                       "Harghita", "Hunedoara", "Ialomița",
                       "Iași", "Ilfov", "Maramureș", "Mehedinți",
                       "Mureș", "Neamț", "Olt", "Prahova",
                       "Sălaj", "Satu Mare", "Sibiu",
                       "Suceava", "Teleorman", "Timiș",
                       "Tulcea", "Vâlcea", "Vaslui",
                       "Vrancea", "Bucarest"]:
            p.agregar_provincia(Provincia(region))
        return p

    # ══════════════════════════════════════
    #  LÍMITES
    # ══════════════════════════════════════

    @staticmethod
    def _limite_bi(a: Pais, b: Pais) -> None:
        a.agregar_limitrofe(b)
        b.agregar_limitrofe(a)

    @staticmethod
    def _cargar_limitrofes_america(america: Continente) -> None:
        paises = {p.nombre: p for p in america.paises}
        lb = Seeder._limite_bi

        argentina  = paises["Argentina"]
        brasil     = paises["Brasil"]
        chile      = paises["Chile"]
        uruguay    = paises["Uruguay"]
        paraguay   = paises["Paraguay"]
        bolivia    = paises["Bolivia"]
        peru       = paises["Perú"]
        colombia   = paises["Colombia"]
        venezuela  = paises["Venezuela"]
        ecuador    = paises["Ecuador"]
        mexico     = paises["México"]
        eeuu       = paises["Estados Unidos"]
        canada     = paises["Canadá"]
        guatemala  = paises["Guatemala"]
        honduras   = paises["Honduras"]
        costa_rica = paises["Costa Rica"]
        panama     = paises["Panamá"]

        # Países sin provincias usados solo para límites
        guyana  = Pais("Guyana",  "Georgetown", 214_969)
        surinam = Pais("Surinam", "Paramaribo", 163_820)

        # Argentina
        lb(argentina, chile); lb(argentina, bolivia); lb(argentina, paraguay)
        lb(argentina, brasil); lb(argentina, uruguay)

        # Brasil
        lb(brasil, uruguay); lb(brasil, paraguay); lb(brasil, bolivia)
        lb(brasil, peru); lb(brasil, colombia); lb(brasil, venezuela)
        lb(brasil, guyana); lb(brasil, surinam)

        # Chile
        lb(chile, peru); lb(chile, bolivia)

        # Bolivia
        lb(bolivia, paraguay); lb(bolivia, peru)

        # Colombia
        lb(colombia, venezuela); lb(colombia, ecuador)
        lb(colombia, peru); lb(colombia, panama)

        # Venezuela
        lb(venezuela, guyana)

        # Ecuador
        lb(ecuador, peru)

        # América Central
        lb(mexico, guatemala); lb(mexico, eeuu)
        lb(guatemala, honduras); lb(honduras, costa_rica)
        lb(costa_rica, panama); lb(canada, eeuu)

    @staticmethod
    def _cargar_limitrofes_europa(europa: Continente) -> None:
        paises = {p.nombre: p for p in europa.paises}
        lb = Seeder._limite_bi

        espana      = paises["España"]
        francia     = paises["Francia"]
        alemania    = paises["Alemania"]
        italia      = paises["Italia"]
        portugal    = paises["Portugal"]
        polonia     = paises["Polonia"]
        paises_bajos = paises["Países Bajos"]
        belgica     = paises["Bélgica"]
        suiza       = paises["Suiza"]
        austria     = paises["Austria"]
        suecia      = paises["Suecia"]
        noruega     = paises["Noruega"]
        finlandia   = paises["Finlandia"]
        dinamarca   = paises["Dinamarca"]
        grecia      = paises["Grecia"]
        checia      = paises["República Checa"]
        hungria     = paises["Hungría"]
        rumania     = paises["Rumanía"]

        andorra    = Pais("Andorra",    "Andorra la Vella", 468)
        luxemburgo = Pais("Luxemburgo", "Luxemburgo",     2_586)

        lb(espana, portugal); lb(espana, francia); lb(espana, andorra)
        lb(francia, belgica); lb(francia, luxemburgo); lb(francia, alemania)
        lb(francia, suiza); lb(francia, italia)
        lb(alemania, paises_bajos); lb(alemania, belgica); lb(alemania, luxemburgo)
        lb(alemania, suiza); lb(alemania, austria); lb(alemania, checia)
        lb(alemania, polonia); lb(alemania, dinamarca)
        lb(austria, suiza); lb(austria, italia); lb(austria, checia)
        lb(austria, hungria); lb(austria, rumania)
        lb(polonia, checia); lb(polonia, hungria); lb(polonia, rumania)
        lb(suecia, noruega); lb(suecia, finlandia); lb(noruega, finlandia)
        lb(hungria, rumania); lb(grecia, rumania)
