class Provincia:
    """Representa una provincia, estado o departamento."""

    def __init__(self, nombre: str):
        self.nombre = nombre

    def __str__(self) -> str:
        return f"Provincia: {self.nombre}"

    def __repr__(self) -> str:
        return f"Provincia('{self.nombre}')"
