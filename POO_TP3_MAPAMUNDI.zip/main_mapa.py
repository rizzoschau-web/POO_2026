from seeder import Seeder
from menu import menu


if __name__ == "__main__":
    print("  Cargando datos del mundo...")
    continentes = Seeder.inicializar_datos()
    total_paises = sum(len(c.paises) for c in continentes.values())
    print(f"  ✓ {len(continentes)} continentes | {total_paises} países cargados.")
    menu(continentes)
