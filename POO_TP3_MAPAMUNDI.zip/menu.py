from geografia import Pais, Continente


# ─────────────────────────────────────────────
#  FUNCIONES DE BÚSQUEDA
# ─────────────────────────────────────────────

def buscar_continente(continentes: dict[str, Continente], nombre: str) -> Continente | None:
    nombre_lower = nombre.strip().lower()
    for c in continentes.values():
        if c.nombre.lower() == nombre_lower:
            return c
    return None


def buscar_pais(continentes: dict[str, Continente], nombre: str) -> Pais | None:
    nombre_lower = nombre.strip().lower()
    for continente in continentes.values():
        for pais in continente.paises:
            if pais.nombre.lower() == nombre_lower:
                return pais
    return None


def todos_los_paises(continentes: dict[str, Continente]) -> list[Pais]:
    resultado = []
    for continente in continentes.values():
        resultado.extend(continente.paises)
    return resultado


# ─────────────────────────────────────────────
#  FUNCIONES DE VISUALIZACIÓN
# ─────────────────────────────────────────────

def separador(titulo: str = "") -> None:
    ancho = 55
    if titulo:
        print(f"\n{'─' * 4} {titulo} {'─' * max(0, ancho - len(titulo) - 6)}")
    else:
        print("─" * ancho)


# ─────────────────────────────────────────────
#  OPCIONES DEL MENÚ
# ─────────────────────────────────────────────

def opcion_listar_paises(continentes: dict[str, Continente]) -> None:
    nombre = input("  Ingrese nombre del continente: ")
    continente = buscar_continente(continentes, nombre)
    if continente:
        separador(f"Países de {continente.nombre}")
        for i, pais in enumerate(continente.paises, 1):
            print(f"  {i:2}. {pais.nombre} (capital: {pais.capital})")
    else:
        print(f"  ⚠ Continente '{nombre}' no encontrado.")


def opcion_listar_provincias(continentes: dict[str, Continente]) -> None:
    nombre = input("  Ingrese nombre del país: ")
    pais = buscar_pais(continentes, nombre)
    if pais:
        separador(f"Provincias de {pais.nombre}")
        if pais.provincias:
            for i, prov in enumerate(pais.provincias, 1):
                print(f"  {i:3}. {prov.nombre}")
        else:
            print("  (Sin provincias registradas)")
    else:
        print(f"  ⚠ País '{nombre}' no encontrado.")


def opcion_listar_limitrofes(continentes: dict[str, Continente]) -> None:
    nombre = input("  Ingrese nombre del país: ")
    pais = buscar_pais(continentes, nombre)
    if pais:
        separador(f"Limítrofes de {pais.nombre}")
        if pais.limitrofes:
            for i, lim in enumerate(pais.limitrofes, 1):
                print(f"  {i:2}. {lim.nombre}")
        else:
            print("  (Sin países limítrofes registrados)")
    else:
        print(f"  ⚠ País '{nombre}' no encontrado.")


def opcion_ordenar_por_superficie(continentes: dict[str, Continente]) -> None:
    separador("Países por superficie (mayor → menor)")
    paises_ord = sorted(todos_los_paises(continentes),
                        key=lambda p: p.superficie_km2, reverse=True)
    for i, p in enumerate(paises_ord, 1):
        print(f"  {i:2}. {p.nombre:<30} {p.superficie_km2:>12,.0f} km²")


def opcion_comparar_paises(continentes: dict[str, Continente]) -> None:
    nombre1 = input("  Ingrese el primer país: ")
    nombre2 = input("  Ingrese el segundo país: ")
    p1 = buscar_pais(continentes, nombre1)
    p2 = buscar_pais(continentes, nombre2)
    if p1 and p2:
        separador("Comparación de superficie")
        print(f"  {p1.nombre}: {p1.superficie_km2:,.0f} km²")
        print(f"  {p2.nombre}: {p2.superficie_km2:,.0f} km²")
        if p1.superficie_km2 > p2.superficie_km2:
            diff = p1.superficie_km2 - p2.superficie_km2
            print(f"\n  ✅ {p1.nombre} es más grande por {diff:,.0f} km²")
        elif p2.superficie_km2 > p1.superficie_km2:
            diff = p2.superficie_km2 - p1.superficie_km2
            print(f"\n  ✅ {p2.nombre} es más grande por {diff:,.0f} km²")
        else:
            print("\n  ↔ Ambos países tienen la misma superficie.")
    else:
        if not p1:
            print(f"  ⚠ País '{nombre1}' no encontrado.")
        if not p2:
            print(f"  ⚠ País '{nombre2}' no encontrado.")


# ─────────────────────────────────────────────
#  MENÚ PRINCIPAL
# ─────────────────────────────────────────────

def menu(continentes: dict[str, Continente]) -> None:
    opciones = {
        "1": opcion_listar_paises,
        "2": opcion_listar_provincias,
        "3": opcion_listar_limitrofes,
        "4": opcion_ordenar_por_superficie,
        "5": opcion_comparar_paises,
    }

    while True:
        print("\n" + "═" * 55)
        print("       🌍  MAPA MUNDIAL  🌎")
        print("═" * 55)
        print("  1. Listar países de un continente")
        print("  2. Listar provincias de un país")
        print("  3. Listar países limítrofes de un país")
        print("  4. Todos los países ordenados por superficie")
        print("  5. Comparar dos países por superficie")
        print("  0. Salir")
        print("═" * 55)
        opcion = input("  Opción: ").strip()

        if opcion == "0":
            print("\n  ¡Hasta luego! 🌐\n")
            break
        elif opcion in opciones:
            opciones[opcion](continentes)
        else:
            print("  ⚠ Opción inválida. Intente nuevamente.")
