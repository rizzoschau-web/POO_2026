from provincia import Provincia


class Pais:
    """Representa un país con capital, superficie, provincias y limítrofes."""

    def __init__(self, nombre: str, capital: str, superficie_km2: float):
        self.nombre = nombre
        self.capital = capital
        self.superficie_km2 = superficie_km2
        self.continente = None          # se asigna al agregarlo a un Continente
        self.provincias: list[Provincia] = []
        self.limitrofes: list["Pais"] = []

    def agregar_provincia(self, provincia: Provincia) -> None:
        """Agrega una Provincia a la colección del país."""
        self.provincias.append(provincia)

    def agregar_limitrofe(self, pais: "Pais") -> None:
        """Vincula un País limítrofe (relación bidireccional opcional)."""
        if pais not in self.limitrofes:
            self.limitrofes.append(pais)

    def __str__(self) -> str:
        continente_nombre = self.continente.nombre if self.continente else "Sin continente"
        limitrofes_nombres = ", ".join(p.nombre for p in self.limitrofes) if self.limitrofes else "Ninguno"
        return (
            f"País         : {self.nombre}\n"
            f"  Capital    : {self.capital}\n"
            f"  Superficie : {self.superficie_km2:,.0f} km²\n"
            f"  Continente : {continente_nombre}\n"
            f"  Limítrofes : {limitrofes_nombres}\n"
            f"  Provincias : {len(self.provincias)} registradas"
        )

    def __repr__(self) -> str:
        return f"Pais('{self.nombre}', '{self.capital}', {self.superficie_km2})"


class Continente:
    """Representa un continente que contiene países."""

    def __init__(self, nombre: str):
        self.nombre = nombre
        self.paises: list[Pais] = []

    def agregar_pais(self, pais: Pais) -> None:
        """Agrega un País al continente y establece la referencia inversa."""
        self.paises.append(pais)
        pais.continente = self

    def __str__(self) -> str:
        nombres = ", ".join(p.nombre for p in self.paises) if self.paises else "Sin países"
        return (
            f"Continente : {self.nombre}\n"
            f"  Países   : {nombres}"
        )

    def __repr__(self) -> str:
        return f"Continente('{self.nombre}')"
