public class LineaFactura {
    private int cantidad;
    private Producto producto;

    // Datos históricos: se guarda una "foto" del precio y el IVA
    // en el momento de la venta (Punto 1)
    private double precioUnitarioHistorico;
    private double porcentajeIvaHistorico;

    public LineaFactura(int cantidad, Producto producto) {
        this.cantidad = cantidad;
        this.producto = producto;
        this.precioUnitarioHistorico = producto.getPrecioBase();
        this.porcentajeIvaHistorico = producto.getPorcentajeIva();
    }

    // Experto en Información: la línea calcula su propio neto (Punto 2)
    public double getNetoLinea() {
        return cantidad * precioUnitarioHistorico;
    }

    public int getCantidad() { return cantidad; }
    public Producto getProducto() { return producto; }
    public double getPrecioUnitarioHistorico() { return precioUnitarioHistorico; }
    public double getPorcentajeIvaHistorico() { return porcentajeIvaHistorico; }
}
