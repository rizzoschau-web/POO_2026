import java.util.List;

public class Factura {
    private String tipoComprobante;      // "A" o "B"
    private double porcentajeDescuento;  // Ej: 0.15
    private List<LineaFactura> lineas;

    public Factura(String tipoComprobante, double porcentajeDescuento, List<LineaFactura> lineas) {
        this.tipoComprobante = tipoComprobante;
        this.porcentajeDescuento = porcentajeDescuento;
        this.lineas = lineas;
    }

    public String getTipoComprobante() { return tipoComprobante; }

    // El descuento a promociones solo aplica a Consumidor Final (Factura B)
    private double getDescuentoAplicable() {
        return tipoComprobante.equals("B") ? porcentajeDescuento : 0.0;
    }

    // Factura ya no calcula "a mano": delega en cada línea su propio neto
    // (Experto en Información) y solo agrega los resultados.
    public ResultadoFactura calcularTotales() {
        double descuento = getDescuentoAplicable();
        ResultadoFactura r = new ResultadoFactura();

        for (LineaFactura linea : lineas) {
            // El descuento se aplica línea por línea, ANTES de calcular el IVA,
            // tal como exige ARCA para que el desglose cierre matemáticamente.
            double netoConDescuento = linea.getNetoLinea() * (1 - descuento);
            double ivaLinea = netoConDescuento * linea.getPorcentajeIvaHistorico();

            r.totalNeto += netoConDescuento;
            r.totalFinal += netoConDescuento + ivaLinea;

            if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.21)) {
                r.totalIva21 += ivaLinea;
            } else if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.105)) {
                r.totalIva105 += ivaLinea;
            }
            // Si es Exento (0%), no aporta a ningún acumulador de IVA.
        }

        r.totalIva = r.totalIva21 + r.totalIva105;
        return r;
    }

    private boolean esAlicuota(double alicuota, double valorEsperado) {
        return Math.abs(alicuota - valorEsperado) < 1e-9;
    }
}
