// Fabricación Pura (Punto 4): encargada exclusivamente de la presentación
public class ImpresorFacturaConsola {

    public void imprimir(Factura factura) {
        ResultadoFactura r = factura.calcularTotales();

        if (factura.getTipoComprobante().equals("A")) {
            System.out.println("---- FACTURA A ----");
            System.out.println("Neto: $" + r.totalNeto);
            System.out.println("IVA 21%: $" + r.totalIva21);
            System.out.println("IVA 10.5%: $" + r.totalIva105);
            System.out.println("Total a Pagar: $" + r.totalFinal);
        } else {
            System.out.println("---- FACTURA B ----");
            System.out.println("Total a Pagar: $" + r.totalFinal);
            // Nueva exigencia de ARCA: discriminar el impuesto aunque
            // el consumidor final vea un precio único
            System.out.println("Discriminado - IVA 21%: $" + r.totalIva21);
            System.out.println("Discriminado - IVA 10.5%: $" + r.totalIva105);
        }
    }
}
