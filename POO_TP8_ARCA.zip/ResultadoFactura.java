// Objeto que transporta los totales ya calculados,
// desacoplando el cálculo (Factura) de la impresión (ImpresorFacturaConsola)
public class ResultadoFactura {
    public double totalNeto;
    public double totalIva21;
    public double totalIva105;
    public double totalIva;
    public double totalFinal;
}
