from empresa import Empresa
from empleado import Empleado


def mostrar_menu():
    print("\n╔══════════════════════════════════╗")
    print("║     GESTIÓN DE EMPLEADOS         ║")
    print("╠══════════════════════════════════╣")
    print("║ 1. Registrar empleado            ║")
    print("║ 2. Ver empleado con mayor sueldo ║")
    print("║ 3. Ver sueldo promedio           ║")
    print("║ 4. Salir                         ║")
    print("╚══════════════════════════════════╝")
    print(f"  (Salario Mínimo vigente: ${Empleado.SALARIO_MINIMO:,.0f})")


def main():
    nombre_empresa = input("Ingrese el nombre de la empresa: ")
    empresa = Empresa(nombre_empresa)

    print(f"\n¡Bienvenido al sistema de {empresa.get_nombre()}!")

    continuar = True
    while continuar:
        mostrar_menu()
        opcion = input("\nSeleccione una opción: ").strip()

        if opcion == "1":
            print("\n--- Registrar Nuevo Empleado ---")
            nombre = input("Nombre del empleado: ").strip()
            dni = input("DNI: ").strip()

            sueldo_valido = False
            sueldo = 0.0
            while not sueldo_valido:
                sueldo_str = input("Sueldo: ").strip()
                sueldo_valido = sueldo_str.replace(".", "", 1).isdigit()
                if sueldo_valido:
                    sueldo = float(sueldo_str)
                else:
                    print("⚠ Por favor ingrese un número válido.")

            registrado = empresa.registrar_empleado(nombre, dni, sueldo)

            if registrado:
                # Buscamos el empleado recién registrado para verificar su sueldo real
                emp = None
                for e in empresa.empleados:
                    if e.get_dni() == dni:
                        emp = e
                        break
                print(f"\n✔ Empleado '{nombre}' registrado correctamente.")
                if emp.get_sueldo() > sueldo:
                    print(f"  ⚠ Sueldo ajustado al Salario Mínimo: ${emp.get_sueldo():,.2f}")
                else:
                    print(f"  Sueldo asignado: ${emp.get_sueldo():,.2f}")
            else:
                print(f"\n✘ Ya existe un empleado con DNI {dni}. No se registró.")

        elif opcion == "2":
            empleado_top = empresa.obtener_empleado_mayor_sueldo()
            if empleado_top is None:
                print("\n⚠ No hay empleados registrados.")
            else:
                print("\n--- Empleado con Mayor Sueldo ---")
                print(f"  Nombre : {empleado_top.get_nombre()}")
                print(f"  DNI    : {empleado_top.get_dni()}")
                print(f"  Sueldo : ${empleado_top.get_sueldo():,.2f}")

        elif opcion == "3":
            promedio = empresa.obtener_sueldo_promedio()
            cantidad = empresa.obtener_cantidad_empleados()
            if cantidad == 0:
                print("\n⚠ No hay empleados registrados.")
            else:
                print("\n--- Sueldo Promedio ---")
                print(f"  Total de empleados : {cantidad}")
                print(f"  Sueldo promedio    : ${promedio:,.2f}")

        elif opcion == "4":
            print("\n¡Hasta pronto!")
            continuar = False

        else:
            print("\n⚠ Opción inválida. Intente de nuevo.")


if __name__ == "__main__":
    main()
