class Empleado:
    SALARIO_MINIMO = 271571  # SMVyM Argentina 2025 (en pesos)

    def __init__(self, nombre, dni, sueldo):
        self.nombre = nombre
        self.dni = dni
        self.sueldo = self._validar_sueldo(sueldo)

    def _validar_sueldo(self, sueldo):
        if sueldo < Empleado.SALARIO_MINIMO:
            return Empleado.SALARIO_MINIMO
        return sueldo

    def set_sueldo(self, sueldo):
        self.sueldo = self._validar_sueldo(sueldo)

    def get_nombre(self):
        return self.nombre

    def get_dni(self):
        return self.dni

    def get_sueldo(self):
        return self.sueldo
