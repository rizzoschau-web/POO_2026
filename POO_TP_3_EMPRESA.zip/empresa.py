from empleado import Empleado


class Empresa:

    def __init__(self, nombre):
        self.nombre = nombre
        self.empleados = []

    def registrar_empleado(self, nombre, dni, sueldo):
        """
        Registra un nuevo empleado si el DNI no existe.
        Retorna True si fue registrado, False si el DNI ya existe.
        """
        for emp in self.empleados:
            if emp.get_dni() == dni:
                return False
        nuevo = Empleado(nombre, dni, sueldo)
        self.empleados.append(nuevo)
        return True

    def obtener_empleado_mayor_sueldo(self):
        """
        Devuelve el objeto Empleado con el sueldo más alto.
        Retorna None si no hay empleados.
        """
        if not self.empleados:
            return None
        mayor = self.empleados[0]
        for emp in self.empleados[1:]:
            if emp.get_sueldo() > mayor.get_sueldo():
                mayor = emp
        return mayor

    def obtener_sueldo_promedio(self):
        """
        Devuelve el sueldo promedio de todos los empleados.
        Retorna 0.0 si no hay empleados.
        """
        if not self.empleados:
            return 0.0
        total = 0.0
        for emp in self.empleados:
            total += emp.get_sueldo()
        return total / len(self.empleados)

    def obtener_cantidad_empleados(self):
        return len(self.empleados)

    def get_nombre(self):
        return self.nombre
