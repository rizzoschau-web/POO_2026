/**
 * Representa un automovil que quema combustible (nafta) para desplazarse.
 * Su impacto ecologico se calcula a partir de los kilometros recorridos
 * y el consumo del vehiculo.
 */
public class Auto implements ImpactoEcologico
{
    // Factor de emision aproximado de la nafta: 2.3 kg de CO2 por litro quemado.
    private static final double FACTOR_EMISION_NAFTA = 2.3;

    private String modelo;
    private double kilometrosRecorridos;   // km recorridos (por ejemplo, en un año)
    private double consumoLitrosPorCienKm; // litros consumidos cada 100 km

    public Auto(String modelo, double kilometrosRecorridos, double consumoLitrosPorCienKm)
    {
        this.modelo = modelo;
        this.kilometrosRecorridos = kilometrosRecorridos;
        this.consumoLitrosPorCienKm = consumoLitrosPorCienKm;
    }

    public String getModelo()
    {
        return modelo;
    }

    public double getKilometrosRecorridos()
    {
        return kilometrosRecorridos;
    }

    // Calcula el impacto ecologico del carbono en kg de CO2 emitidos
    @Override
    public double obtenerImpactoEcologico()
    {
        double litrosConsumidos = (kilometrosRecorridos / 100.0) * consumoLitrosPorCienKm;
        return litrosConsumidos * FACTOR_EMISION_NAFTA;
    }

    @Override
    public String toString()
    {
        return String.format("Auto modelo %s (recorrido: %.1f km, consumo: %.1f l/100km)",
                modelo, kilometrosRecorridos, consumoLitrosPorCienKm);
    }
}
