import java.util.ArrayList;

/**
 * Aplicacion que crea objetos de Edificio, Auto y Bicicleta (clases no
 * relacionadas por herencia), los coloca en un ArrayList<ImpactoEcologico>
 * y recorre la lista invocando en forma polimorfica el metodo
 * obtenerImpactoEcologico de cada uno.
 */
public class EjercicioImpactoEcologico
{
    public static void main(String[] args)
    {
        // Se crean objetos de las tres clases no relacionadas entre si
        Edificio edificio = new Edificio("Av. Corrientes 1234", 1500.0);
        Auto auto = new Auto("Toyota Corolla", 12000.0, 7.5);
        Bicicleta bicicleta = new Bicicleta("Urbana", 800.0);

        // Se colocan las referencias en un ArrayList del tipo de la interfaz
        ArrayList<ImpactoEcologico> lista = new ArrayList<>();
        lista.add(edificio);
        lista.add(auto);
        lista.add(bicicleta);

        // Se recorre el ArrayList invocando polimorficamente
        // obtenerImpactoEcologico() sobre cada objeto
        for (ImpactoEcologico objeto : lista)
        {
            // "objeto" tiene tipo declarado ImpactoEcologico, pero en tiempo
            // de ejecucion el enlace dinamico invoca la version del metodo
            // correspondiente al tipo real del objeto (Edificio, Auto o Bicicleta)
            System.out.println(objeto.toString());
            System.out.printf("  Impacto ecologico: %.2f kg de CO2%n%n",
                    objeto.obtenerImpactoEcologico());
        }
    }
}
