/**
 * Representa un edificio que consume combustible (por ejemplo, gas natural)
 * para calefaccion y produccion de energia. Su impacto ecologico se calcula
 * a partir del consumo anual de combustible.
 */
public class Edificio implements ImpactoEcologico
{
    // Factor de emision aproximado del gas natural: 5.3 kg de CO2 por m3 quemado.
    // (Fuente aproximada: EPA - Emission Factors for Greenhouse Gas Inventories)
    private static final double FACTOR_EMISION_GAS = 5.3;

    private String direccion;
    private double consumoAnualGasM3; // metros cubicos de gas consumidos por año

    public Edificio(String direccion, double consumoAnualGasM3)
    {
        this.direccion = direccion;
        this.consumoAnualGasM3 = consumoAnualGasM3;
    }

    public String getDireccion()
    {
        return direccion;
    }

    public double getConsumoAnualGasM3()
    {
        return consumoAnualGasM3;
    }

    // Calcula el impacto ecologico del carbono en kg de CO2 emitidos por año
    @Override
    public double obtenerImpactoEcologico()
    {
        return consumoAnualGasM3 * FACTOR_EMISION_GAS;
    }

    @Override
    public String toString()
    {
        return String.format("Edificio ubicado en %s (consumo anual: %.1f m3 de gas)",
                direccion, consumoAnualGasM3);
    }
}
