/**
 * Representa una bicicleta, un medio de transporte que no quema combustible
 * fosil y por lo tanto no emite dioxido de carbono al usarse.
 */
public class Bicicleta implements ImpactoEcologico
{
    private String tipo;              // por ejemplo: "montaña", "ruta", "urbana"
    private double kilometrosRecorridos;

    public Bicicleta(String tipo, double kilometrosRecorridos)
    {
        this.tipo = tipo;
        this.kilometrosRecorridos = kilometrosRecorridos;
    }

    public String getTipo()
    {
        return tipo;
    }

    public double getKilometrosRecorridos()
    {
        return kilometrosRecorridos;
    }

    // Una bicicleta no consume combustible, por lo que su impacto
    // ecologico del carbono es siempre 0 kg de CO2.
    @Override
    public double obtenerImpactoEcologico()
    {
        return 0.0;
    }

    @Override
    public String toString()
    {
        return String.format("Bicicleta tipo %s (recorrido: %.1f km)",
                tipo, kilometrosRecorridos);
    }
}
