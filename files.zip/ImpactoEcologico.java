/**
 * Interfaz que especifica un comportamiento comun (obtenerImpactoEcologico)
 * para clases que, aunque no esten relacionadas por herencia, comparten
 * la capacidad de generar un impacto ecologico del carbono.
 */
public interface ImpactoEcologico
{
    // Cada clase que implemente esta interfaz debe calcular su propio
    // impacto ecologico del carbono, expresado en kg de CO2 emitidos
    // (por año, en el caso de Edificio y Bicicleta -por su ausencia de
    // emision-, o por kilometro recorrido, en el caso de Auto).
    double obtenerImpactoEcologico();
}
