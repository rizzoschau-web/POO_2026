public interface DescuentoLinea {

    double aplicar(LineaFactura linea);
}
