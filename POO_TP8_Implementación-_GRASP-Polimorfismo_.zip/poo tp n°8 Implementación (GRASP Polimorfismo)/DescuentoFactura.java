public interface DescuentoFactura {

    double aplicar(double subtotal);
}
