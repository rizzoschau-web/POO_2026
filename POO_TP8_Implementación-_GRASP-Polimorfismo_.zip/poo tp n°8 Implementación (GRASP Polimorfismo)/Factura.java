import java.util.List;

public class Factura {

    private String tipoComprobante;
    private List<LineaFactura> lineas;
    private List<DescuentoLinea> descuentosLinea;
    private List<DescuentoFactura> descuentosFactura;

    public Factura(String tipoComprobante,
                   List<LineaFactura> lineas,
                   List<DescuentoLinea> descuentosLinea,
                   List<DescuentoFactura> descuentosFactura) {

        this.tipoComprobante = tipoComprobante;
        this.lineas = lineas;
        this.descuentosLinea = descuentosLinea;
        this.descuentosFactura = descuentosFactura;
    }

    public String getTipoComprobante() {
        return tipoComprobante;
    }

    public ResultadoFactura calcularTotales() {

        ResultadoFactura r = new ResultadoFactura();

        for (LineaFactura linea : lineas) {

            double netoLinea = linea.getNetoLinea();

            for (DescuentoLinea descuento : descuentosLinea) {
                netoLinea = descuento.aplicar(linea);
            }

            double ivaLinea =
                    netoLinea * linea.getPorcentajeIvaHistorico();

            r.totalNeto += netoLinea;
            r.totalFinal += netoLinea + ivaLinea;

            if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.21)) {
                r.totalIva21 += ivaLinea;
            } else if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.105)) {
                r.totalIva105 += ivaLinea;
            }
        }

        r.totalIva = r.totalIva21 + r.totalIva105;

        for (DescuentoFactura descuento : descuentosFactura) {
            r.totalFinal = descuento.aplicar(r.totalFinal);
        }

        return r;
    }

    private boolean esAlicuota(double alicuota, double valorEsperado) {
        return Math.abs(alicuota - valorEsperado) < 1e-9;
    }
}
