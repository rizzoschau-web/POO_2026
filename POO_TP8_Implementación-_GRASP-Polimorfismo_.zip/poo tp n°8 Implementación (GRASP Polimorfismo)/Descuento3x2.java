public class Descuento3x2 implements DescuentoLinea {

    @Override
    public double aplicar(LineaFactura linea) {

        int cantidad = linea.getCantidad();

        int gruposDeTres = cantidad / 3;
        int unidadesRestantes = cantidad % 3;

        int unidadesAPagar = (gruposDeTres * 2) + unidadesRestantes;

        return unidadesAPagar * linea.getPrecioUnitarioHistorico();
    }
}
