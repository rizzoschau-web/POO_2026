public class DescuentoPorVolumen implements DescuentoFactura {

    private double montoMinimo;
    private double porcentaje;

    public DescuentoPorVolumen(double montoMinimo, double porcentaje) {
        this.montoMinimo = montoMinimo;
        this.porcentaje = porcentaje;
    }

    @Override
    public double aplicar(double subtotal) {

        if (subtotal >= montoMinimo) {
            return subtotal - (subtotal * porcentaje);
        }

        return subtotal;
    }
}
