import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DemoParte4 {
    public static void main(String[] args) {

        // CatalogoProductos: único que crea Producto
        CatalogoProductos catalogo = new CatalogoProductos();
        catalogo.registrarProducto("Detergente", 1000.0, 0.21);
        catalogo.registrarProducto("Carne", 2000.0, 0.105);
        catalogo.registrarProducto("Leche", 800.0, 0.0);

        // GestorDeVentas: crea la Factura
        GestorDeVentas gestor = new GestorDeVentas(catalogo);

        Map<String, Integer> pedido = new HashMap<>();
        pedido.put("Detergente", 3);
        pedido.put("Carne", 2);
        pedido.put("Leche", 5);

        List<DescuentoLinea> descuentosLinea = new ArrayList<>();
        descuentosLinea.add(new Descuento3x2());

        List<DescuentoFactura> descuentosFacturaA = new ArrayList<>(); // sin descuento global
        List<DescuentoFactura> descuentosFacturaB = new ArrayList<>();
        descuentosFacturaB.add(new DescuentoPorVolumen(5000.0, 0.15)); // ej: Jubilados

        Factura facturaA = gestor.registrarVenta("A", pedido, descuentosLinea, descuentosFacturaA);
        gestor.emitirTicket(facturaA);

        Factura facturaB = gestor.registrarVenta("B", pedido, descuentosLinea, descuentosFacturaB);
        gestor.emitirTicket(facturaB);
    }
}
