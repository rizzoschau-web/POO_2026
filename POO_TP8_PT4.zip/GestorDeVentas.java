import java.util.List;
import java.util.Map;

// GRASP Creador: GestorDeVentas conoce el pedido del cliente y el catálogo
// de productos, por lo tanto tiene los datos necesarios para inicializar
// una Factura. Factura no puede autocrearse: no tiene forma de saber
// cuándo empieza una venta ni qué pidió el cliente.
public class GestorDeVentas {

    private CatalogoProductos catalogo;
    private ImpresorFacturaConsola impresor = new ImpresorFacturaConsola();

    public GestorDeVentas(CatalogoProductos catalogo) {
        this.catalogo = catalogo;
    }

    public Factura registrarVenta(String tipoComprobante,
                                   Map<String, Integer> pedido,
                                   List<DescuentoLinea> descuentosLinea,
                                   List<DescuentoFactura> descuentosFactura) {

        // Creador de Factura
        Factura factura = new Factura(tipoComprobante, descuentosLinea, descuentosFactura);

        for (Map.Entry<String, Integer> item : pedido.entrySet()) {
            Producto producto = catalogo.buscar(item.getKey());
            // Delega en Factura, que es el Creador de LineaFactura
            factura.agregarLinea(producto, item.getValue());
        }

        return factura;
    }

    public void emitirTicket(Factura factura) {
        impresor.imprimir(factura);
    }
}
