import java.util.ArrayList;
import java.util.List;

public class Factura {

    private String tipoComprobante;
    private List<LineaFactura> lineas;
    private List<DescuentoLinea> descuentosLinea;
    private List<DescuentoFactura> descuentosFactura;

    // GRASP Creador: el constructor ya NO recibe la lista de líneas armada
    // desde afuera. Factura arranca vacía y va creando sus propias líneas
    // a medida que se le agregan productos.
    public Factura(String tipoComprobante,
                   List<DescuentoLinea> descuentosLinea,
                   List<DescuentoFactura> descuentosFactura) {

        this.tipoComprobante = tipoComprobante;
        this.lineas = new ArrayList<>();
        this.descuentosLinea = descuentosLinea;
        this.descuentosFactura = descuentosFactura;
    }

    // GRASP Creador: Factura contiene y usa intensamente a LineaFactura
    // (la recorre por completo en calcularTotales()), por lo tanto es ella
    // quien la instancia. Quien arma la venta (GestorDeVentas) no necesita
    // conocer el constructor de LineaFactura: solo indica producto y cantidad.
    public LineaFactura agregarLinea(Producto producto, int cantidad) {
        LineaFactura linea = new LineaFactura(cantidad, producto);
        lineas.add(linea);
        return linea;
    }

    public String getTipoComprobante() {
        return tipoComprobante;
    }

    public ResultadoFactura calcularTotales() {

        ResultadoFactura r = new ResultadoFactura();

        for (LineaFactura linea : lineas) {

            double netoLinea = linea.getNetoLinea();

            for (DescuentoLinea descuento : descuentosLinea) {
                netoLinea = descuento.aplicar(linea);
            }

            double ivaLinea =
                    netoLinea * linea.getPorcentajeIvaHistorico();

            r.totalNeto += netoLinea;
            r.totalFinal += netoLinea + ivaLinea;

            if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.21)) {
                r.totalIva21 += ivaLinea;
            } else if (esAlicuota(linea.getPorcentajeIvaHistorico(), 0.105)) {
                r.totalIva105 += ivaLinea;
            }
        }

        r.totalIva = r.totalIva21 + r.totalIva105;

        for (DescuentoFactura descuento : descuentosFactura) {
            r.totalFinal = descuento.aplicar(r.totalFinal);
        }

        return r;
    }

    private boolean esAlicuota(double alicuota, double valorEsperado) {
        return Math.abs(alicuota - valorEsperado) < 1e-9;
    }
}
