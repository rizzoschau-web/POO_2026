import java.util.HashMap;
import java.util.Map;

// GRASP Creador: es la única clase autorizada a instanciar Producto.
// Centraliza el catálogo (precios y alícuotas vigentes) y evita que
// Factura o LineaFactura creen productos "sueltos" por su cuenta.
public class CatalogoProductos {

    private Map<String, Producto> productos = new HashMap<>();

    public Producto registrarProducto(String nombre, double precioBase, double porcentajeIva) {
        Producto p = new Producto(nombre, precioBase, porcentajeIva); // único punto de creación
        productos.put(nombre, p);
        return p;
    }

    public Producto buscar(String nombre) {
        Producto p = productos.get(nombre);
        if (p == null) {
            throw new IllegalArgumentException("Producto inexistente: " + nombre);
        }
        return p;
    }
}
